﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Triangales
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            // Проверка на заполненность каждого поля
            if (string.IsNullOrWhiteSpace(tbA.Text) || string.IsNullOrWhiteSpace(tbB.Text) || string.IsNullOrWhiteSpace(tbC.Text))
            {
                textResult.Text = "Ошибка: все поля должны быть заполнены";
                return;
            }

            // Проверка на отсутствие запрещённых символов (только цифры)
            string[] inputs = { tbA.Text, tbB.Text, tbC.Text };
            foreach (string n in inputs)
            {
                if (n.All(char.IsDigit) == false)
                {
                    textResult.Text = "Ошибка: разрешены только цифры 0-9";
                    return;
                }
            }

            // Проверка на пропуск нулей как первых цифр
            foreach (string n in inputs)
            {
                if (n[0] == '0')
                {
                    textResult.Text = "Ошибка: нули в начале числа не допускаются";
                    return;
                }
            }

            // Проверка на переполнение полей (не более 15 цифр)
            foreach (string n in inputs)
            {
                if (n.Length > 15)
                {
                    textResult.Text = "Ошибка: число не может содержать более 15 цифр";
                    return;
                }
            }

            double a = double.Parse(tbA.Text);
            double b = double.Parse(tbB.Text);
            double c = double.Parse(tbC.Text);


            // Проверка на существование треугольника
            if (a + b <= c || a + c <= b || b + c <= a)
            {
                textResult.Text = "Ошибка: треугольник с такими сторонами не существует";
                return;
            }

            // Определяем тип треугольника
            if (a == b && b == c)
            {
                textResult.Text = "Треугольник равносторонний";
            }
            else if (a == b || a == c || b == c)
            {
                textResult.Text = "Треугольник равнобедренный";
            }
            else
            {
                textResult.Text = "Треугольник разносторонний";
            }
        }
    }
}
